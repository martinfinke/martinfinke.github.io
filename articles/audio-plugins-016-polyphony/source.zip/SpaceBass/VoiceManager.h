//
//  VoiceManager.h
//  SpaceBass
//
//  Created by Martin on 08.04.14.
//
//

#ifndef __SpaceBass__VoiceManager__
#define __SpaceBass__VoiceManager__

#include "Voice.h"

class VoiceManager {
public:
    void onNoteOn(int noteNumber, int velocity);
    void onNoteOff(int noteNumber, int velocity);
    double nextSample();
private:
    static const int NumberOfVoices = 64;
    Voice voices[NumberOfVoices];
    Oscillator mLFO;
    Voice* findFreeVoice();
};

#endif /* defined(__SpaceBass__VoiceManager__) */
